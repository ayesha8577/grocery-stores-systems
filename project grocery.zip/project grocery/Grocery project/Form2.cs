﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace total
{
    public partial class Form2 : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter adapter;
        DataTable dt;
        public Form2()
        {
            InitializeComponent();
        }
        void GetItems()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\last.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM Items", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            GetItems();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Items(Item,Price)" +
                   "VALUES (@item,@price)";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@item", Itembox.Text);
            cmd.Parameters.AddWithValue("@price", Pricebox.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Inserted data ");
            GetItems();
            IDbox.Clear();
            Itembox.Clear();
            Pricebox.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Items SET Item = @item, Price = @price WHERE ID = @id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@item", Itembox.Text);
            cmd.Parameters.AddWithValue("@price", Pricebox.Text);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(IDbox.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Updated ");
            GetItems();
            IDbox.Clear();
            Itembox.Clear();
            Pricebox.Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Items WHERE ID = @id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(IDbox.Text));
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Delete");
            GetItems();
            IDbox.Clear();
            Itembox.Clear();
            Pricebox.Clear();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            IDbox.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            Itembox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            Pricebox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
          
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Home h1 = new Home();
            h1.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            IDbox.Clear();
            Itembox.Clear();
            Pricebox.Clear();
        }
    }
}
